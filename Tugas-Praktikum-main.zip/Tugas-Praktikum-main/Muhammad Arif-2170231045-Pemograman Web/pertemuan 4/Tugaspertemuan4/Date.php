<html lang="en">
<head>
    <title>Date</title>
</head>
<body>


<?php 

        echo "1. ".date("d F Y")."<br/>";

        echo "2. ".date("l, d F Y")."<br/>";

 

        echo "<br/>";

 

        echo "3. ".date("H:i:s")."<br/>";

        echo "4. ".date("h:i:s A")."<br/>";

 

        echo "<br/>";

 

        echo "5. ".date("d/m/Y H:i:s")."<br/>";

?>


</body>
</html>