<html>
<head>
<title> Pemograman PHP dengan Array </title>
</head>
<body>
<?php
//penulisan array dengan dibuat seperti berikut
$nama[] = "Agung Teguh";
$nama [] = "Wibowo";
$nama [] = "Almais";
echo $nama[1] . $nama[2] . $nama [0];
echo "<br>";
?>
</body>
</html>
