<?php 
echo "Data Kosong";
?>