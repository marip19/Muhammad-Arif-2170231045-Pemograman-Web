<?php 
$angka=90;
?>