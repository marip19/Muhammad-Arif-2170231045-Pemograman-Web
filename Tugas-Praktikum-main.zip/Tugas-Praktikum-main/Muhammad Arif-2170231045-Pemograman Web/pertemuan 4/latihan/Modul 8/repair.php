<html>
    <head>
        <meta http-equiv="refresh" content="2"; url="http://localhost/modul8/test.html">
    </head>
    <body>
        Tes Redirect
    </body>
</html>