<?php 
if (isset($variable_cookies)) {
	echo 'Variable Cookiesnya "$variable_cookies" nilainya adalah' .$variable_cookies;
} else {
	echo "Variable Cookies Belum Diterapkan";
}
?>